var autotime=(function(){function e(e){return e}var t=`candidate-profile`,n=`reusable-answers`,r=`saved-applications`,i=`application-content-draft`,a=`account-session`,o=`diagnostic-log`,s=150;function c(e){return{fullName:e.fullName??``,email:e.email??``,phone:e.phone??``,linkedInUrl:e.linkedInUrl??``,githubUrl:e.githubUrl??``,portfolioUrl:e.portfolioUrl??``,currentCountry:e.currentCountry??``,currentCity:e.currentCity??``,targetCountries:e.targetCountries??``,targetRoles:e.targetRoles??``,workRightDetails:e.workRightDetails??``,sponsorshipNeeded:e.sponsorshipNeeded??!1,relocationWillingness:e.relocationWillingness??`depends`,salaryExpectation:e.salaryExpectation??``,noticePeriod:e.noticePeriod??``,baseCvText:e.baseCvText??``,projectSummaries:e.projectSummaries??``,experienceHighlights:e.experienceHighlights??``}}function l(e){return{sponsorshipAnswer:e.sponsorshipAnswer??``,relocationAnswer:e.relocationAnswer??``,workAuthorisationAnswer:e.workAuthorisationAnswer??``,noticePeriodAnswer:e.noticePeriodAnswer??``,salaryExpectationAnswer:e.salaryExpectationAnswer??``,motivationAnswer:e.motivationAnswer??``,strengthsAnswer:e.strengthsAnswer??``,availabilityAnswer:e.availabilityAnswer??``}}function u(e){switch(e){case`Checking fit`:case`Ready to apply`:case`Applied`:case`Interview`:case`Offer`:case`Rejected`:case`Archived`:case`Saved`:return e;case`Applying`:return`Ready to apply`;case`applied`:return`Applied`;case`interview`:return`Interview`;case`offer`:return`Offer`;case`rejected`:return`Rejected`;case`closed`:case`Closed`:return`Archived`;default:return`Saved`}}function d(e){let t={...e,status:u(e.status)};return e.contentSnapshot!==void 0&&(t.contentSnapshot=f(e.contentSnapshot)),t}function f(e){return{coverLetter:e.coverLetter??``,profileSummary:e.profileSummary??``,motivationAnswer:e.motivationAnswer??``,strengthsAnswer:e.strengthsAnswer??``,availabilityAnswer:e.availabilityAnswer??``,savedAt:e.savedAt??new Date().toISOString()}}function p(e){return!e.authToken?.trim()||!e.email?.trim()?null:{authToken:e.authToken,refreshToken:e.refreshToken??``,expiresAt:Number.isFinite(e.expiresAt)?Number(e.expiresAt):0,email:e.email,plan:e.plan===`pro`?`pro`:`free`,provider:e.provider?.trim()||`email`}}function m(){return globalThis.crypto?.randomUUID?.()??`${Date.now()}-${Math.random().toString(36).slice(2)}`}function ee(e){if(e)return Object.fromEntries(Object.entries(e).filter(([e])=>!/token|secret|password|authorization/i.test(e)).map(([e,t])=>typeof t==`string`||typeof t==`number`||typeof t==`boolean`||t===null?[e,t]:[e,String(t)]))}function h(e){return{id:e.id??m(),area:e.area===`connect`||e.area===`sync`||e.area===`widget`||e.area===`sidepanel`?e.area:`connect`,createdAt:e.createdAt??new Date().toISOString(),details:ee(e.details),event:e.event??`unknown`,message:e.message,status:e.status===`success`||e.status===`warning`||e.status===`error`?e.status:`info`}}async function g(){let e=(await chrome.storage.local.get(t))[t];return e?c(e):null}async function te(){let e=(await chrome.storage.local.get(n))[n];return e?l(e):null}async function ne(){return(await chrome.storage.local.get(i))[i]??null}async function re(){return((await chrome.storage.local.get(o))[o]??[]).map(h)}async function _(e){let t=await re(),n=h(e);return await chrome.storage.local.set({[o]:[n,...t].slice(0,s)}),n}async function v(){let e=(await chrome.storage.local.get(a))[a];return e?p(e):null}async function ie(){return((await chrome.storage.local.get(r))[r]??[]).map(d)}async function ae(e){let t=await ie(),n=[d(e),...t];await chrome.storage.local.set({[r]:n})}function y(e=``){return e.replace(/<[^>]*>/g,` `).replace(/&nbsp;/gi,` `).replace(/&amp;/gi,`&`).replace(/&lt;/gi,`<`).replace(/&gt;/gi,`>`).replace(/&quot;/gi,`"`).replace(/&#39;|&apos;/gi,`'`).replace(/\s+/g,` `).trim()}function b(e){if(Array.isArray(e))return e.map(b).find(Boolean)??``;if(typeof e==`number`)return String(e);if(typeof e==`string`)return y(e);if(!e||typeof e!=`object`)return``;let t=e;return b(t.name)||b(t.value)}function x(e){if(Array.isArray(e))return e.flatMap(x);if(!e||typeof e!=`object`)return[];let t=e;return[t,...x(t[`@graph`]),...x(t.itemListElement)]}function oe(e,t){let n=e[`@type`];return Array.isArray(n)?n.includes(t):n===t}function se(e){let t=Array.isArray(e)?e[0]:e;if(typeof t==`string`)return y(t);if(!t||typeof t!=`object`)return``;let n=t,r=n.address&&typeof n.address==`object`?n.address:n;return[b(r.addressLocality),b(r.addressRegion),b(r.addressCountry)].filter(Boolean).join(`, `)}function ce(e){return Array.isArray(e)?e.map(ce).filter(Boolean).join(`, `):b(e)}function le(e){if(Array.isArray(e))return e.map(le).find(Boolean)??``;if(typeof e==`number`||typeof e==`string`)return b(e);if(!e||typeof e!=`object`)return``;let t=e,n=t.value,r=typeof n==`object`&&n?n:null,i=b(r?.minValue??t.minValue),a=b(r?.maxValue??t.maxValue),o=b(r?.value??n),s=i&&a?`${i}-${a}`:o||i||a;return[b(t.currency??r?.currency),s,b(r?.unitText??t.unitText)].filter(Boolean).join(` `)}function ue(e){let t=x(e).find(e=>oe(e,`JobPosting`));return t?{roleTitle:b(t.title),company:b(t.hiringOrganization),location:se(t.jobLocation)||se(t.applicantLocationRequirements)||(b(t.jobLocationType)===`TELECOMMUTE`?`Remote`:b(t.jobLocationType)),salary:le(t.baseSalary),employmentType:ce(t.employmentType),description:b(t.description)}:null}function de(e=``){try{return new URL(e).hostname.replace(/^www\./,``)}catch{return``}}function S(e,t){return e===t||e.endsWith(`.${t}`)}function fe(e){return S(e,`indeed.com`)||/^indeed\.[a-z.]+$/i.test(e)}function pe(e=``){let t=e.match(/\/jobs\/view\/(\d+)/i),n=e.match(/[?&]currentJobId=(\d+)/i);return t?.[1]??n?.[1]??``}function C(e=``){let t=de(e);return S(t,`linkedin.com`)?`LinkedIn`:S(t,`stepstone.de`)||S(t,`stepstone.com`)?`Stepstone`:fe(t)?`Indeed`:S(t,`eures.europa.eu`)||S(t,`eures.ec.europa.eu`)?`EURES`:S(t,`eurotechjobs.com`)?`EuroTechJobs`:S(t,`eurojobs.com`)?`EuroJobs`:S(t,`nextleveljobs.eu`)?`NextLevelJobs`:S(t,`wellfound.com`)||S(t,`angel.co`)?`Wellfound`:S(t,`xing.com`)?`Xing`:S(t,`welcometothejungle.com`)?`WelcomeToTheJungle`:S(t,`nationalevacaturebank.nl`)?`NationaleVacaturebank`:S(t,`infojobs.net`)||S(t,`infojobs.it`)?`InfoJobs`:S(t,`monster.com`)||S(t,`monster.co.uk`)||S(t,`monster.de`)||S(t,`monster.fr`)?`Monster`:S(t,`eurotoptech.com`)?`EuroTopTech`:S(t,`jobteaser.com`)?`JobTeaser`:S(t,`greenhouse.io`)?`Greenhouse`:S(t,`lever.co`)?`Lever`:S(t,`myworkdayjobs.com`)?`Workday`:S(t,`ashbyhq.com`)?`Ashby`:S(t,`smartrecruiters.com`)?`SmartRecruiters`:S(t,`icims.com`)?`iCIMS`:S(t,`bamboohr.com`)?`BambooHR`:S(t,`teamtailor.com`)?`Teamtailor`:S(t,`recruitee.com`)?`Recruitee`:S(t,`jobvite.com`)?`Jobvite`:S(t,`personio.de`)||S(t,`personio.com`)?`Personio`:`Generic`}function w(e=``){return C(e)===`LinkedIn`}function me(e=``){if(!w(e))return y(e);try{let t=new URL(e),n=pe(e);if(n)return`${t.origin}/jobs/view/${n}/`}catch{return y(e)}return y(e)}function he(e=``){let t=e.split(`|`).map(e=>y(e)).filter(Boolean);if(t.length<3||!/^linkedin$/i.test(t[t.length-1]??``))return{company:``,title:``};let n=t[0]??``,r=t[1]??``;return{company:T(r,8,100)?r:``,title:T(n,12,120)?n:``}}function ge(e=``){return y(e).replace(/^job application for\s+/i,``).replace(/^job description\s*[:|-]\s*/i,``).replace(/^job opening\s*[:|-]\s*/i,``).replace(/^apply for\s+/i,``).trim()}function _e(e=``){return ve(e)?``:y(e).replace(/\s+(?:salary|compensation|about(?:\s+the\s+(?:opportunity|role|company))?|the\s+role|role|key\s+responsibilities|responsibilities|requirements|profile|what(?:'|’)s\s+on\s+offer|benefits|application|how\s+to\s+apply)\b.*$/i,``).replace(/[.;,:\-\s]+$/,``).trim()}function ve(e=``){return/https?:\/\/|www\.|linkedin\.com|currentJobId=|%2f|%3a/i.test(e)}function ye(e=``){let t=y(e).toLowerCase();return!t||ve(t)||/^(not tracked yet|not detected|waiting|parsed from job board|job details|wide)$/i.test(t)}function T(e=``,t=12,n=120){let r=y(e);return!(ye(r)||r.split(/\s+/).filter(Boolean).length>t||r.length>n||/\b(?:salary|compensation|equity|responsibilities|requirements|send|cv|video|about the|working with|you will|we are|job description|key responsibilities)\b/i.test(r))}function be(e=``){let t=_e(e);return!(ye(t)||t.split(/\s+/).filter(Boolean).length>10||t.length>90||/\b(?:salary|compensation|equity|opportunity|company|business|role|responsibilities|requirements|experience|application|apply|send|cv|video|about|working|supporting|generated|revenue|students|organisations|organization)\b/i.test(t)||/[£$€]\s*\d|\b\d{2,3},\d{3}\b/.test(t))}function xe(e=``){let t=ge(e);return T(t,12,120)?t:``}function Se(e=``){let t=y(e);return T(t,8,100)?t:``}function Ce(e=``){let t=_e(e);return be(t)?t:``}function we(e=``){let t=e.replace(/\r\n/g,`
`);for(let e of[/\bLocation\s*[:|-]\s*([A-Z][A-Za-z .'-]+,\s*(?:United Kingdom|UK|Ireland|Germany|France|Spain|Portugal|Italy|Netherlands|Belgium|Switzerland|Austria|Poland|Sweden|Norway|Denmark|Finland|Europe))(?:\s|$)/i,/\bLocation\s*[:|-]\s*([^\n<]+)/i,/\b[Ll]ocation\s+([A-Z][A-Za-z .'-]+(?:\s*\([^)]{2,80}\))?)/,/\bJob location\s*[:|-]\s*([^\n<]+)/i,/\bOffice\s*:\s*([^\n<]+)/i,/\bWorkplace\s*[:|-]\s*([^\n<]+)/i,/\bBase(?:d)?\s*:\s*([^\n<]+)/i,/\bBased in\s+([A-Z][A-Za-z .'-]+(?:,\s*[A-Z][A-Za-z .'-]+)?)/i,/\b(?:Hybrid|Remote|On-site|Onsite)\s*(?:role|working)?\s*(?:in|from|-\s*)\s*([A-Z][A-Za-z .'-]+(?:,\s*[A-Z][A-Za-z .'-]+)?)/i]){let n=_e(t.match(e)?.[1]);if(be(n))return n}return``}function Te(e){let t=y(e.url),n=C(t),r=xe(e.heading),i=Se(e.company),a=y(e.description),o=y(e.salary),s=y(e.employmentType);return{roleTitle:r,company:i,location:Ce(e.location)||we(e.description),jobDescription:a,url:t,source:y(e.source)||de(t),platform:n,pageTitle:y(e.title),...o?{salary:o}:{},...s?{employmentType:s}:{}}}function Ee(e){return[e.location&&`Location: ${e.location}`,e.salary&&`Salary: ${e.salary}`,e.employmentType&&`Employment type: ${e.employmentType}`,e.platform!==`Generic`&&`Platform: ${e.platform}`,e.source&&`Source: ${e.source}`,e.pageTitle&&`Page title: ${e.pageTitle}`].filter(Boolean).join(`
`)}function E(e){try{let t=new URL(e);return t.hash=``,t.hostname=t.hostname.toLowerCase(),t.pathname=t.pathname.replace(/\/+$/,``),t.toString().replace(/\/$/,``).toLowerCase()}catch{return e.trim().toLowerCase().replace(/\/$/,``)}}function De(e,t){let n=E(t);return e.some(e=>E(e.url)===n)}var D=`https://autotime-eu-apply.vercel.app`;`${D}`;var Oe=new Set([``,`email`,`search`,`tel`,`text`,`url`]);function ke(e){let t=e.trim().split(/\s+/).filter(Boolean);return{firstName:t[0]??``,lastName:t.slice(1).join(` `)}}function Ae(e){let{firstName:t,lastName:n}=ke(e.fullName);return{firstName:t,lastName:n,email:e.email,phone:e.phone}}function je(e){return{sponsorshipAnswer:e.sponsorshipAnswer,relocationAnswer:e.relocationAnswer,workAuthorisationAnswer:e.workAuthorisationAnswer,noticePeriodAnswer:e.noticePeriodAnswer,salaryExpectationAnswer:e.salaryExpectationAnswer,motivationAnswer:e.motivationAnswer,strengthsAnswer:e.strengthsAnswer,availabilityAnswer:e.availabilityAnswer}}function Me(e){return{coverLetter:e.coverLetter,profileSummary:e.profileSummary,motivationAnswer:e.motivationAnswer,strengthsAnswer:e.strengthsAnswer,availabilityAnswer:e.availabilityAnswer}}function O(e,t){return t.some(t=>e.includes(t))}function Ne(e,t){let n=t.toLowerCase();return e===`email`||O(n,[`email`,`e-mail`])?`email`:e===`tel`||O(n,[`phone`,`mobile`,`telephone`,`tel`])?`phone`:n.includes(`given-name`)||n.includes(`firstname`)||n.includes(`first name`)||n.includes(`forename`)?`firstName`:n.includes(`family-name`)||n.includes(`lastname`)||n.includes(`last name`)||n.includes(`surname`)?`lastName`:null}function Pe(e){let t=e.toLowerCase();return O(t,[`sponsor`,`sponsorship`,`visa support`,`require a visa`,`need a visa`])?`sponsorshipAnswer`:O(t,[`relocat`,`move to`,`willing to move`])?`relocationAnswer`:O(t,[`authorised to work`,`authorized to work`,`work authorisation`,`work authorization`,`right to work`,`eligible to work`])?`workAuthorisationAnswer`:O(t,[`notice period`,`start date`,`available to start`])?`noticePeriodAnswer`:O(t,[`salary`,`compensation`,`expected pay`,`pay expectation`,`desired pay`])?`salaryExpectationAnswer`:O(t,[`why are you interested`,`why do you want`,`why this role`,`motivation`,`why join`])?`motivationAnswer`:O(t,[`strength`,`strengths`,`what can you bring`,`why are you a good fit`,`relevant experience`])?`strengthsAnswer`:O(t,[`availability`,`available for interview`])?`availabilityAnswer`:null}function Fe(e){let t=e.toLowerCase();return O(t,[`cover letter`,`covering letter`,`supporting statement`,`personal statement`])?`coverLetter`:O(t,[`profile summary`,`professional summary`,`brief summary`,`about you`,`tell us about yourself`])?`profileSummary`:O(t,[`why are you interested`,`why do you want`,`why this role`,`motivation`,`why join`])?`motivationAnswer`:O(t,[`strength`,`strengths`,`what can you bring`,`why are you a good fit`,`relevant experience`])?`strengthsAnswer`:O(t,[`availability`,`available for interview`])?`availabilityAnswer`:null}function Ie(e){return!e.disabled&&!e.readOnly&&e.isVisible&&Oe.has(e.type)&&e.value.trim()===``}var k=`autotime-draggable-job-widget`,A=`autotime-draggable-job-widget-position`,j=`autotime-toggle-widget`,Le=`autotime-close-widget`,Re=12,M=480,N=360,ze=360,Be=300,P=64,F=64,Ve={company:[],description:[],location:[],title:[]},I=null,He=!1,Ue=`No job description found. Update your description and click the button below to retrieve insights.`,We=[`python`,`openai`,`anthropic`,`llm`,`rag`,`nlp`,`api`,`document`,`financial`,`dashboard`,`data`,`analysis`,`modelling`,`legal`,`risk`,`market`];function L(e){let t=Array.from(e.labels??[]).map(e=>e.textContent??``).join(` `),n=e.parentElement?.textContent??``;return[e.name,e.id,e.placeholder,e.getAttribute(`aria-label`),t,n].filter(Boolean).join(` `).toLowerCase()}function R(e=``){return e.trim()?e.trim().split(/\s+/).filter(Boolean).length:0}function Ge(e=``){let t=e.toLowerCase();return We.filter(e=>t.includes(e)).slice(0,6)}function Ke(e){if(!e?.jobDescription.trim())return[Ue];let t=R(e.jobDescription),n=Ge(e.jobDescription);return[e.platform===`Generic`?`Detected from the current job page.`:`Detected from ${e.platform}.`,`${t} words in the visible job description.`,e.location?`Location signal: ${e.location}.`:`Location was not clearly detected.`,n.length>0?`Core signals: ${n.join(`, `)}.`:`No keyword signals detected yet.`]}function qe(e){if(!e)return[`Role positioning angle`,`Evidence gaps against the job description`,`Application risk and priority recommendation`];let t=Ge(e.jobDescription),n=e.roleTitle||`this role`,r=e.company||`the company`;return[`Position ${n} around ${t[0]??`the strongest repeated job signal`}.`,`Prepare evidence for ${t.slice(0,3).join(`, `)||`the top requirements`} before applying.`,`Review ${r} fit, location and work-right risk in the dashboard before sending materials.`]}function Je(){try{let e=JSON.parse(localStorage.getItem(A)??`{}`);if(typeof e.left==`number`||typeof e.top==`number`||typeof e.width==`number`||typeof e.height==`number`||typeof e.closed==`boolean`)return e}catch{}return null}function z(e,t){let n=Math.max(ze,window.innerWidth-24),r=Math.max(Be,window.innerHeight-24);return{width:Math.min(Math.max(ze,e),n),height:Math.min(Math.max(Be,t),r)}}function B(e,t,n=M,r=N){let i=Math.max(12,window.innerWidth-n-12),a=Math.max(12,window.innerHeight-r-12);return{left:Math.min(Math.max(12,e),i),top:Math.min(Math.max(12,t),a)}}function Ye(){try{return JSON.parse(localStorage.getItem(A)??`{}`)}catch{return{}}}function V(e){try{localStorage.setItem(A,JSON.stringify({...Ye(),...e}))}catch{}}function H(e,t){V({left:e,top:t})}function Xe(e,t){V({height:t,width:e})}function Ze(e){let t=e.roleTitle||e.pageTitle||e.url;return{id:crypto.randomUUID(),title:t,roleTitle:e.roleTitle||t,company:e.company||void 0,url:e.url,source:e.source,createdAt:new Date().toISOString(),status:`Saved`,notes:[e.jobDescription,Ee(e)].filter(Boolean).join(`

`)}}function Qe(e){return e instanceof Error?e.message:`Dashboard sync failed`}function U(e){return`Dashboard sync failed: ${e}`}var $e=2e4;function et(e,t){return new Promise(n=>{let r=!1,i,a=e=>{r||(r=!0,i!==void 0&&window.clearTimeout(i),n(e))};i=window.setTimeout(()=>{_({area:`sync`,event:`widget-sync-timed-out`,message:`Background sync did not respond in time.`,status:`warning`,details:{applicationCount:e.length}}),a({ok:!1,reason:U(`Dashboard sync timed out. The job is saved locally - try Track Job again.`),synced:!1})},$e),chrome.runtime.sendMessage({applications:e,resurrectUrlKeys:t,type:`AUTOTIME_SYNC_APPLICATIONS`},e=>{if(chrome.runtime.lastError){a({ok:!1,reason:U(chrome.runtime.lastError.message??`Extension background sync could not be reached.`),synced:!1});return}a(e??{ok:!1,reason:U(`Extension background sync did not respond.`),synced:!1})})})}async function tt(e,t){let n=await v();if(_({area:`sync`,event:`track-job-sync-requested`,message:`Widget requested dashboard sync through the background worker.`,status:`info`,details:{applicationCount:e.length}}),!n?.authToken.trim())return{reason:`Click Connect to sync to dashboard`,synced:!1};try{let r=await et(e,t);return r.synced?(_({area:`sync`,event:`track-job-sync-completed`,message:`Tracked jobs synced to dashboard.`,status:`success`,details:{applicationCount:e.length}}),{connected:!0,synced:!0}):{connected:r.connected??!!n?.authToken.trim(),reason:r.reason??r.error??U(`Extension background sync failed.`),synced:!1}}catch(t){let r=U(Qe(t));return _({area:`sync`,event:`track-job-sync-failed`,message:r,status:`warning`,details:{applicationCount:e.length}}),{connected:!!n?.authToken.trim(),reason:r,synced:!1}}}function nt(e){return Ne(e.type,L(e))}function rt(e){return Pe(L(e))}function it(e){return Fe(L(e))}function at(e){return Ie({disabled:e.disabled,readOnly:e.readOnly,isVisible:e.getClientRects().length>0,type:e.type,value:e.value})}function ot(e){return!e.disabled&&!e.readOnly&&e.getClientRects().length>0&&e.value.trim()===``}function W(e,t){let n=Object.getOwnPropertyDescriptor(e,`value`)?.set,r=Object.getOwnPropertyDescriptor(Object.getPrototypeOf(e),`value`)?.set;r&&n!==r?r.call(e,t):e.value=t,e.dispatchEvent(new Event(`input`,{bubbles:!0})),e.dispatchEvent(new Event(`change`,{bubbles:!0}))}function st(e){for(let t of e){let e=document.querySelector(`meta[name="${t}"], meta[property="${t}"]`)?.content.trim();if(e)return e}return``}function G(e=``){return e.replace(/\s+/g,` `).trim()}function K(e){if(Array.isArray(e))return e.flatMap(K);if(!e||typeof e!=`object`)return[];let t=e;return[t,...K(t[`@graph`]),...K(t.itemListElement)]}function ct(e,t){let n=e[`@type`];return Array.isArray(n)?n.includes(t):n===t}function lt(){let e=Array.from(document.querySelectorAll(`script[type="application/ld+json"]`));for(let t of e)try{let e=K(JSON.parse(t.textContent??``)).find(e=>ct(e,`JobPosting`));if(e)return e}catch{}return null}function ut(e){switch(e){case`Xing`:return{title:[`[data-testid='job-title']`,`[data-qa='job-title']`,`h1`],company:[`[data-testid='company-name']`,`[data-qa='company-name']`,`a[href*='/pages/']`],location:[`[data-testid='job-location']`,`[data-testid='location']`,`[data-qa='job-location']`],description:[`[data-testid='job-description']`,`[data-qa='job-description']`,`[class*='job-description']`,`[class*='JobDescription']`]};case`WelcomeToTheJungle`:return{title:[`[data-testid='job-title']`,`h1`],company:[`[data-testid='company-name']`,`[data-testid='job-company-name']`,`a[href*='/companies/']`],location:[`[data-testid='job-location']`,`[data-testid='job-office-location']`,`[class*='JobLocation']`],description:[`[data-testid='job-description']`,`[data-testid='job-section-description']`,`[data-testid='job-profile']`,`[class*='JobDescription']`]};case`NationaleVacaturebank`:return{title:[`[data-testid='vacancy-title']`,`[data-testid='job-title']`,`h1`],company:[`[data-testid='company-name']`,`.vacancy-company`,`.vacature-company`,`[class*='company']`],location:[`[data-testid='job-location']`,`[data-testid='location']`,`.vacancy-location`,`.vacature-location`],description:[`[data-testid='vacancy-description']`,`[data-testid='job-description']`,`.vacancy-description`,`.vacature-description`,`[class*='vacancy-description']`]};case`InfoJobs`:return{title:[`[data-testid='job-title']`,`h1`],company:[`[data-testid='company-name']`,`.ij-OfferDetailHeader-companyName`,`a[href*='/empresa/']`],location:[`[data-testid='job-location']`,`.ij-OfferDetailHeader-location`,`[class*='location']`],description:[`[data-testid='job-description']`,`.ij-OfferDetailDescription`,`#prefijoDescripcion1`,`[class*='OfferDetailDescription']`]};case`Monster`:return{title:[`[data-testid='job-title']`,`[data-testid='svx-job-title']`,`h1`],company:[`[data-testid='company-name']`,`[data-testid='svx-company-name']`,`.company`,`[class*='company']`],location:[`[data-testid='job-location']`,`[data-testid='svx-job-location']`,`.location`,`[class*='location']`],description:[`[data-testid='job-description']`,`[data-testid='svx-job-description']`,`#JobDescription`,`.job-description`,`[class*='description']`]};case`EuroTopTech`:return{title:[`h1`,`[data-testid='job-title']`,`.job-title`],company:[`[data-testid='company-name']`,`.company`,`.job-company`],location:[`[data-testid='job-location']`,`.location`,`.job-location`],description:[`[data-testid='job-description']`,`.job-description`,`.description`,`#job-description`]};case`JobTeaser`:return{title:[`[data-testid='job-title']`,`h1`],company:[`[data-testid='company-name']`,`[data-testid='organization-name']`,`a[href*='/companies/']`],location:[`[data-testid='job-location']`,`[data-testid='location']`,`[class*='location']`],description:[`[data-testid='job-description']`,`[data-testid='offer-description']`,`[class*='description']`]};default:return Ve}}function q(e,t=()=>!0){for(let n of e){let e=document.querySelector(n),r=G(e?.innerText||e?.textContent||``);if(r&&t(r))return r}return``}function dt(e){return e?G(Array.from(e.childNodes).filter(e=>e.nodeType===Node.TEXT_NODE).map(e=>e.textContent??``).join(` `)):``}function J(e=``){return G(e).replace(/[*:：\-\s]+$/g,``).toLowerCase()}function Y(e,t){let n=new Set(e.map(J));for(let e of document.querySelectorAll(`dt`)){if(!n.has(J(e.innerText||e.textContent||``)))continue;let r=G(e.parentElement?.querySelector(`dd`)?.textContent||``)||G(e.nextElementSibling?.textContent||``);if(r&&t(r))return r}for(let e of document.querySelectorAll(`th`)){if(!n.has(J(e.innerText||e.textContent||``)))continue;let r=G(e.nextElementSibling?.textContent||e.parentElement?.querySelector(`td`)?.textContent||``);if(r&&t(r))return r}let r=RegExp(`^(${e.map(e=>e.replace(/[.*+?^${}()|[\]\\]/g,`\\$&`)).join(`|`)})\\s*[:：-]\\s*(.+)$`,`i`);for(let e of document.querySelectorAll(`li, p, span, div`)){let n=G(dt(e).match(r)?.[2]||``);if(n&&t(n))return n}return``}function ft(e=``,t=12,n=120){let r=G(e),i=r.split(/\s+/).filter(Boolean);return ht(r)&&r.length>0&&r.length<=n&&i.length<=t&&!/\b(?:salary|compensation|equity|responsibilities|requirements|send|cv|video|about the|working with|you will|we are|job description|key responsibilities)\b/i.test(r)}function pt(e=``){return/https?:\/\/|www\.|linkedin\.com|currentJobId=|%2f|%3a/i.test(e)}function mt(e=``){return/^(not tracked yet|not detected|waiting|parsed from job board|job details|wide)$/i.test(G(e))}function ht(e=``){let t=G(e);return!!t&&!pt(t)&&!mt(t)}function gt(e=``){return ft(e,12,120)}function X(e=``){return ft(e,8,100)}function Z(e=``){let t=Ot(e),n=t.split(/\s+/).filter(Boolean);return ht(t)&&t.length>0&&t.length<=90&&n.length<=10&&!/\b(?:salary|compensation|equity|opportunity|company|business|role|responsibilities|requirements|experience|application|apply|send|cv|video|about|working|supporting|generated|revenue|students|organisations|organization)\b/i.test(t)&&!/[Â£$â‚¬]\s*\d|\b\d{2,3},\d{3}\b/.test(t)}function _t(e){return e.flatMap(e=>Array.from(document.querySelectorAll(e)).map(e=>G(e.innerText||e.textContent||``)).filter(Boolean)).sort((e,t)=>t.length-e.length)[0]??``}function vt(e=``){return G(e).replace(/^About the job\s*/i,``).replace(/^About the role\s*/i,``).replace(/\bShow more\b|\bShow less\b/gi,``).replace(/\s+/g,` `).trim()}function yt(){return(document.body?.innerText||document.body?.textContent||``).replace(/\r\n/g,`
`).replace(/\n{3,}/g,`

`).trim()}function bt(e,t,n){let r=e.toLowerCase();for(let i of t){let t=r.indexOf(i.toLowerCase());if(t===-1)continue;let a=t+i.length,o=n.reduce((e,t)=>{let n=r.indexOf(t.toLowerCase(),a);return n!==-1&&n<e?n:e},e.length);return e.slice(a,o)}return``}function xt(){let e=bt(yt(),[`About the job`,`About the role`,`Job description`,`Description`],[`
Seniority level`,`
Employment type`,`
Job function`,`
Industries`,`
Referrals increase`,`
See who`,`
Show more jobs`,`
Similar jobs`]);return R(e)>=10?vt(e):``}function St(){let e=_t([`#job-details`,`.jobs-description`,`.jobs-description__container`,`.jobs-description__content`,`.jobs-box__html-content`,`.jobs-description-content__text`,`.show-more-less-html__markup`,`[class*='jobs-description']`]);return R(e)>=10?vt(e):xt()}function Ct(e=[]){if(w(window.location.href)){let e=St();if(e)return e}let t=_t([...e,`.jobs-description__content`,`.jobs-box__html-content`,`.jobs-description-content__text`,`.show-more-less-html__markup`,`[data-test-job-description]`,`[data-testid='job-description']`,`[data-testid='description']`,`[data-qa='job-description']`,`[data-ph-at-id='description-text']`,`[data-ui='job-description']`,`[data-automation-id='jobPostingDescription']`,`[data-automation-id='jobDescription']`,`[itemprop='description']`,`#job-description`,`#jobDescription`,`.posting-description`,`.job-description`,`.jobsearch-JobComponent-description`,`.description__text`,`.ats-description`,`.job-posting-description`,`section.description`]);return R(t)>=20?t:Array.from(document.querySelectorAll(`article, main, section, div[id], div[class], section[id], section[class]`)).filter(e=>{let t=[e.id,e.className,e.getAttribute(`data-testid`),e.getAttribute(`data-automation-id`),e.getAttribute(`aria-label`)].filter(Boolean).join(` `).toLowerCase();return/description|details|posting|job-content|jobcontent/.test(t)}).map(e=>G(e.innerText||e.textContent||``)).filter(e=>R(e)>=20).sort((e,t)=>t.length-e.length)[0]??t}function wt(){return q([`.job-details-jobs-unified-top-card__primary-description-container`,`.jobs-unified-top-card__primary-description-container`,`.jobs-unified-top-card__subtitle-primary-grouping`,`.topcard__flavor-row`])}function Tt(e=``){return e.split(/(?:\s*(?:\u00b7|\u2022|\u00c2\u00b7)\s*|\n+)/).map(e=>e.trim()).filter(Boolean)}function Et(){return Tt(wt()).filter(e=>!/^(verified|follow|promoted)$/i.test(e)).find(e=>X(e)&&!/\b(?:applicant|reposted|posted|remote|hybrid|on-site|onsite|full-time|part-time|contract)\b/i.test(e))??``}function Dt(){return Tt(wt()).filter(e=>!/^(verified|follow|promoted)$/i.test(e)).find((e,t)=>t>0&&Z(e)&&!/\b(?:applicant|reposted|posted|actively recruiting|promoted|remote|hybrid|on-site|onsite|full-time|part-time|contract)\b/i.test(e))??``}function Ot(e=``){let t=G(e).replace(/\b(?:reposted|posted)\s+\d+\s+(?:minute|hour|day|week|month)s?\s+ago\b.*$/i,``).replace(/\b\d+\s+(?:minute|hour|day|week|month)s?\s+ago\b.*$/i,``).replace(/\b\d+\s+applicants?.*$/i,``).replace(/\bActively recruiting\b.*$/i,``).trim(),n=Tt(t).filter(e=>!/\b(?:applicant|reposted|posted|promoted|actively recruiting)\b/i.test(e));return n.length>0?n[0]:t.split(/(?:\s*[·•]\s*|\s+\u00c2\u00b7\s+|\n+)/).map(e=>e.trim()).filter(Boolean).filter(e=>!/\b(?:applicant|reposted|posted|promoted|actively recruiting)\b/i.test(e))[0]??``}function Q(){let e=C(window.location.href),t=ue(lt()),n=e===`LinkedIn`,r=ut(e),i=t?.location??``,a=t?.roleTitle??``,o=t?.description??``,s=t?.salary??``,c=t?.employmentType??``,l=st([`og:title`,`twitter:title`])||document.title||a,u=n?he(l):{company:``,title:``},d=t?.company||q([...r.company,`.jobs-unified-top-card__company-name a`,`.jobs-unified-top-card__company-name`,`.job-details-jobs-unified-top-card__company-name a`,`.job-details-jobs-unified-top-card__company-name`,`.job-details-jobs-unified-top-card__primary-description-container a`,`.topcard__org-name-link`,`.posting-headline .company`,`.company-name`,`[data-testid='company-name']`,`[data-testid='job-company-name']`,`[data-testid='company']`,`[data-ui='company-name']`,`[data-automation-id='jobPostingCompany']`,`[data-automation-id='company']`],X)||Y([`Company`,`Organization`,`Organisation`,`Employer`],X)||(n?Et()||u.company:``),f=i||(n?Ot(q([`.jobs-unified-top-card__bullet`,`.job-details-jobs-unified-top-card__bullet`,`.topcard__flavor--bullet`,`[data-automation-id='job-details-location']`],Z)||Dt()):q([...r.location,`.posting-categories .location`,`.location`,`[data-testid='job-location']`,`[data-testid='location']`,`[data-ui='job-location']`,`[data-automation-id='locations']`,`[data-automation-id='job-details-location']`],Z)||Y([`Location`,`Job location`,`Office`,`Workplace`,`Base`],Z)),p=Te({title:l,heading:a||q([...r.title,`.job-details-jobs-unified-top-card__job-title h1`,`.jobs-unified-top-card__job-title`,`.job-details-jobs-unified-top-card__job-title`,`.jobs-unified-top-card__job-title h1`,`.jobs-unified-top-card__job-title a`,`.job-details-jobs-unified-top-card__job-title a`,`.topcard__title`,`.posting-headline h2`,`.app-title`,`[data-testid='job-title']`,`[data-testid='jobTitle']`,`[data-ui='job-title']`,`[data-automation-id='jobPostingHeader']`],gt)||(n?u.title:``)||Y([`Job title`,`Role title`,`Position`,`Title`],gt),company:d,employmentType:c,location:f,salary:s,description:o||Ct(r.description),url:n?me(window.location.href):window.location.href});return!p.roleTitle&&!p.company?{...p,message:`Could not detect job details on this page`}:p}function kt(){return document.querySelector(`.jobs-easy-apply-modal, [data-test-modal-id="easy-apply-modal"]`)}function At(){return w(window.location.href)?kt()||{filledFields:[],message:`Open the LinkedIn Easy Apply modal before filling.`}:document}function jt(e){return`filledFields`in e}async function Mt(){let e=At();if(jt(e))return e;let t=await g(),n=await te();if(!t&&!n)return{filledFields:[],message:`No saved profile or reusable answers found`};let r=t?Ae(t):null,i=n?je(n):null,a=[];return e.querySelectorAll(`input`).forEach(e=>{if(!r||!at(e))return;let t=nt(e);!t||!r[t]||(W(e,r[t]),a.push(t))}),e.querySelectorAll(`textarea`).forEach(e=>{if(!i||!ot(e))return;let t=rt(e);!t||!i[t]||(W(e,i[t]),a.push(t))}),{filledFields:a}}async function Nt(){let e=At();if(jt(e))return e;let t=await ne();if(!t)return{filledFields:[],message:`No saved application content found`};let n=Me(t),r=[];return e.querySelectorAll(`textarea`).forEach(e=>{if(!ot(e))return;let t=it(e);!t||!n[t]||(W(e,n[t]),r.push(t))}),{filledFields:r}}function $(e){return e.replace(/&/g,`&amp;`).replace(/</g,`&lt;`).replace(/>/g,`&gt;`).replace(/"/g,`&quot;`).replace(/'/g,`&#039;`)}function Pt(e,t=``){return`<ul${t?` class="${t}"`:``}>${e.map(e=>`<li>${$(e)}</li>`).join(``)}</ul>`}function Ft(e){switch(e){case`github`:return`GitHub`;case`google`:return`Google`;case`email`:return`Email sign-in`;default:return e}}function It({accountSession:e,details:t,status:n}){let r=e?.plan===`pro`,i=!!e?.authToken.trim(),a=i?`${D}/dashboard`:`${D}/extension/connect?extensionId=${encodeURIComponent(chrome.runtime.id)}`,o=!!t?.jobDescription.trim(),s=Ke(t),c=qe(t),l=t?.roleTitle||`Not tracked yet`,u=t?.company||`Not detected`,d=t?.location||`Not detected`,f=t?.platform||`Waiting`,p=t?.source||`Waiting`,m=t?.jobDescription.trim()??``,ee=m?`${R(m)} words parsed`:`Not parsed yet`,h=o||r,g=n.toLowerCase(),te=/^tracking/i.test(n)?`Please wait while AutoTime saves this role.`:g.includes(`synced to dashboard`)?`Saved roles appear in the AutoTime dashboard tracker.`:g.includes(`dashboard sync failed`)?i?`Dashboard account is connected, but the sync request failed. Retry Track Job or check extension logs.`:`Use the Connect button in this widget to link your dashboard account.`:g.includes(`saved locally`)||g.includes(`tracked in extension`)||g.includes(`connect the extension`)?i?`Saved locally in the extension. Retry Track Job to sync this role to the dashboard.`:`Use the Connect button in this widget to link your dashboard account.`:g.includes(`already tracked`)?`This role is already saved locally in the extension.`:`Check the visible job page and try again.`;return`
    <style>
      :host {
        color: #172033;
        font-family: Inter, ui-sans-serif, -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, Helvetica, Arial, sans-serif;
        font-size: 13px;
        line-height: 1.4;
      }

      * {
        box-sizing: border-box;
      }

      .widget {
        display: grid;
        grid-template-rows: auto auto minmax(0, 1fr) auto;
        position: relative;
        width: min(var(--autotime-widget-width, ${M}px), calc(100vw - 24px));
        height: min(var(--autotime-widget-height, ${N}px), calc(100vh - 24px));
        border: 1px solid #bdd4dc;
        border-left: 4px solid #007c78;
        border-radius: 8px;
        background: linear-gradient(135deg, #ffffff 0%, #edf8f7 100%);
        box-shadow: 0 18px 45px rgba(6, 22, 47, 0.18);
        overflow: hidden;
      }

      .launcher {
        display: none;
        place-items: center;
        width: 56px;
        height: 56px;
        border: 1px solid #bdd4dc;
        border-left: 4px solid #007c78;
        border-radius: 8px;
        background: linear-gradient(135deg, #ffffff 0%, #edf8f7 100%);
        box-shadow: 0 14px 34px rgba(6, 22, 47, 0.2);
        cursor: move;
      }

      :host([data-autotime-minimized="true"]) .widget {
        display: none;
      }

      :host([data-autotime-minimized="true"]) .launcher {
        display: grid;
      }

      :host([data-autotime-closed="true"]) .widget,
      :host([data-autotime-closed="true"]) .launcher {
        display: none;
      }

      .handle {
        display: grid;
        gap: 8px;
        padding: 10px 12px 12px;
        border-bottom: 1px solid #bdd4dc;
        cursor: move;
        user-select: none;
      }

      .handle-main {
        display: flex;
        align-items: center;
        gap: 8px;
        min-width: 0;
      }

      .account-identity {
        display: flex;
        align-items: center;
        flex-wrap: wrap;
        gap: 6px;
        max-width: 100%;
        font-size: 11px;
        font-weight: 600;
        line-height: 1.35;
        padding: 3px 8px;
        border-radius: 999px;
        width: fit-content;
        overflow-wrap: anywhere;
      }

      .account-identity-dot {
        width: 7px;
        height: 7px;
        border-radius: 50%;
        flex: 0 0 auto;
      }

      .account-identity-connected {
        color: #14643f;
        background: #e7f7ee;
      }

      .account-identity-connected .account-identity-dot {
        background: #1f9d5c;
      }

      .account-identity-disconnected {
        color: #8a4b00;
        background: #fff3e0;
      }

      .account-identity-disconnected .account-identity-dot {
        background: #d97a06;
      }

      .brand-logo,
      .launcher-logo img {
        width: 28px;
        height: 28px;
        border: 1px solid #c9d4e6;
        border-radius: 6px;
        background: #ffffff;
        object-fit: contain;
      }

      .brand-mark {
        display: inline-grid;
        flex: 0 0 auto;
        place-items: center;
        width: 32px;
        height: 32px;
      }

      .launcher-logo,
      .icon-button {
        display: inline-grid;
        flex: 0 0 auto;
        place-items: center;
        width: 32px;
        height: 32px;
        padding: 0;
        border: 0;
        border-radius: 7px;
        background: transparent;
        box-shadow: none;
        cursor: pointer;
      }

      .header-action-button {
        width: 100%;
        min-width: 0;
        min-height: 34px;
        padding: 0 12px;
        box-shadow: 0 5px 12px rgba(0, 108, 103, 0.18);
        font-size: 11.5px;
      }

      .header-dashboard-button {
        border-color: #bdd4dc;
        background: #ffffff;
        box-shadow: none;
        color: #075c59;
      }

      .header-dashboard-button:hover {
        border-color: #007c78;
        background: #edf8f7;
      }

      .launcher-logo:hover,
      .icon-button:hover {
        background: #dff2f0;
      }

      .title-block {
        display: grid;
        flex: 1 1 auto;
        min-width: 0;
        gap: 1px;
      }

      .handle strong {
        color: #06162f;
        font-size: 13px;
        font-weight: 700;
        overflow: hidden;
        text-overflow: ellipsis;
        white-space: nowrap;
      }

      .handle span {
        color: #5b6475;
        font-size: 11px;
        font-weight: 600;
      }

      .window-controls {
        display: flex;
        flex: 0 0 auto;
        align-items: center;
        gap: 4px;
        margin-left: auto;
      }

      .header-actions {
        display: grid;
        grid-template-columns: repeat(2, minmax(0, 1fr));
        gap: 8px;
      }

      .status-alert {
        display: grid;
        gap: 3px;
        max-height: 86px;
        margin: 8px 10px 0;
        padding: 9px 10px;
        border: 1px solid #8bcfc8;
        border-left: 4px solid #007c78;
        border-radius: 8px;
        background: #ecfffb;
        box-shadow: 0 8px 18px rgba(0, 108, 103, 0.16);
        color: #064e4a;
        font-size: 12.5px;
        font-weight: 700;
        line-height: 1.35;
        overflow-y: auto;
        overflow-wrap: anywhere;
      }

      .status-alert small {
        color: #47716e;
        font-size: 11px;
        font-weight: 600;
        line-height: 1.3;
      }

      .grid {
        display: grid;
        grid-template-columns: minmax(0, 1fr) minmax(0, 1fr);
        gap: 10px;
        min-height: 0;
        overflow-y: auto;
        overscroll-behavior: contain;
        padding: 12px;
      }

      .panel {
        display: grid;
        align-content: start;
        gap: 10px;
        min-width: 0;
      }

      .eyebrow {
        margin: 0 0 3px;
        color: #006c67;
        font-size: 10px;
        font-weight: 700;
        letter-spacing: 0;
        text-transform: uppercase;
      }

      h3 {
        margin: 0;
        color: #06162f;
        font-size: 14px;
        font-weight: 700;
        line-height: 1.25;
      }

      ul {
        display: grid;
        gap: 7px;
        margin: 0;
        padding-left: 16px;
      }

      li {
        color: #172033;
        font-size: 12.5px;
        line-height: 1.45;
      }

      .empty-list {
        padding-left: 0;
        list-style: none;
      }

      .empty-list li,
      .deep,
      .detail-row,
      .upgrade-note {
        border: 1px solid #d6deeb;
        border-radius: 8px;
        background: #ffffff;
      }

      .empty-list li {
        padding: 9px;
        color: #4d5768;
        font-weight: 600;
      }

      .deep {
        display: grid;
        gap: 8px;
        padding: 9px;
      }

      .blurred {
        filter: blur(4px);
        pointer-events: none;
        user-select: none;
      }

      .upgrade-note {
        margin: 0;
        padding: 9px;
        color: #075c59;
        background: #edf8f7;
        font-size: 12.5px;
        font-weight: 600;
      }

      a {
        color: #005f5a;
        font-weight: 700;
        text-decoration: underline;
        text-underline-offset: 3px;
      }

      .details {
        display: grid;
        gap: 8px;
        margin: 0;
      }

      .detail-row {
        display: grid;
        gap: 3px;
        min-width: 0;
        padding: 9px;
      }

      dt {
        color: #5b6475;
        font-size: 10px;
        font-weight: 700;
        text-transform: uppercase;
      }

      dd {
        margin: 0;
        min-width: 0;
        color: #172033;
        font-size: 12.5px;
        font-weight: 600;
        overflow-wrap: anywhere;
      }

      .description-row dd {
        display: grid;
        gap: 7px;
      }

      .description-body {
        max-height: min(220px, calc(var(--autotime-widget-height, ${N}px) * 0.46));
        overflow-y: auto;
        overscroll-behavior: contain;
        padding: 8px;
        border: 1px solid #d6deeb;
        border-radius: 7px;
        background: #f8fbfc;
        color: #253149;
        font-size: 12px;
        font-weight: 500;
        line-height: 1.45;
        white-space: pre-wrap;
      }

      button {
        min-width: 116px;
        min-height: 36px;
        padding: 0 14px;
        border: 1px solid #006c67;
        border-radius: 8px;
        background: #007c78;
        box-shadow: 0 6px 14px rgba(0, 108, 103, 0.18);
        color: #ffffff;
        cursor: pointer;
        font: inherit;
        font-size: 12px;
        font-weight: 700;
        letter-spacing: 0;
        white-space: nowrap;
      }

      button:hover {
        border-color: #004f4b;
        background: #006c67;
      }

      button:disabled {
        cursor: wait;
        opacity: 0.72;
      }

      button.icon-button,
      button.launcher-logo {
        min-width: 32px;
        min-height: 32px;
        padding: 0;
        border: 0;
        background: transparent;
        box-shadow: none;
        color: #324054;
        font-size: 18px;
        line-height: 1;
      }

      button.icon-button {
        font-weight: 700;
      }

      button.icon-button:hover,
      button.launcher-logo:hover {
        border: 0;
        background: #dff2f0;
        color: #06162f;
      }

      .resize-handle {
        position: absolute;
        right: 0;
        bottom: 0;
        width: 18px;
        height: 18px;
        min-width: 18px;
        min-height: 18px;
        padding: 0;
        border: 0;
        background: linear-gradient(135deg, transparent 50%, #007c78 51%);
        box-shadow: none;
        cursor: nwse-resize;
        opacity: 0.75;
      }

      .resize-handle:hover {
        opacity: 1;
      }

      @media (max-width: 420px) {
        .grid {
          grid-template-columns: minmax(0, 1fr);
        }

        .header-action-button {
          padding: 0 8px;
        }
      }
    </style>
    <section class="widget" aria-label="AutoTime job tracker">
      <div class="handle" data-autotime-drag-handle>
        <div class="handle-main">
          <div class="brand-mark" aria-hidden="true">
            <img class="brand-logo" alt="" aria-hidden="true" src="${chrome.runtime.getURL(`icons/128.png`)}" />
          </div>
          <div class="title-block">
            <strong>AutoTime EU Apply</strong>
            <span>Drag to move</span>
          </div>
          <div class="window-controls" aria-label="Widget controls">
            <button class="icon-button" data-autotime-collapse-widget type="button" title="Close" aria-label="Close AutoTime widget">&times;</button>
          </div>
        </div>
        <div class="account-identity ${i?`account-identity-connected`:`account-identity-disconnected`}">
          <span class="account-identity-dot" aria-hidden="true"></span>
          ${i&&e?`Signed in as ${$(e.email)} via ${$(Ft(e.provider))}`:`Not connected - tracked jobs save locally only`}
        </div>
        <div class="header-actions" aria-label="Widget actions">
          <button class="header-action-button" data-autotime-track-job type="button">TRACK JOB</button>
          <button class="header-action-button header-dashboard-button" data-autotime-open-dashboard data-autotime-dashboard-url="${$(a)}" type="button">${i?`Dashboard`:`Connect`}</button>
        </div>
      </div>
      ${n?`<div class="status-alert" role="alert" aria-live="assertive">${$(n)}<small>${$(te)}</small></div>`:``}
      <div class="grid">
        <div class="panel">
          <div>
            <p class="eyebrow">Job insights</p>
            <h3>Basic insight</h3>
          </div>
          ${Pt(s,o?``:`empty-list`)}
          <div class="deep">
            <div>
              <p class="eyebrow">Deep insight</p>
              ${r?`<h3>Pro analysis</h3>`:``}
            </div>
            ${h?Pt(c,r?``:`blurred`):``}
            ${r?o?``:`<p class="upgrade-note">Deep analysis appears after a job description is parsed.</p>`:`<p class="upgrade-note">Deep matching, gaps and priority guidance are available after upgrading. <a href="${D}/pricing" target="_blank" rel="noreferrer">Upgrade to Pro</a></p>`}
          </div>
        </div>
        <aside class="panel" aria-label="Job details">
          <div>
            <p class="eyebrow">Job details</p>
            <h3>Parsed from job board</h3>
          </div>
          <dl class="details">
            <div class="detail-row"><dt>Job title</dt><dd>${$(l)}</dd></div>
            <div class="detail-row"><dt>Company</dt><dd>${$(u)}</dd></div>
            <div class="detail-row"><dt>Location</dt><dd>${$(d)}</dd></div>
            <div class="detail-row"><dt>Platform</dt><dd>${$(f)}</dd></div>
            <div class="detail-row"><dt>Source</dt><dd>${$(p)}</dd></div>
            <div class="detail-row description-row"><dt>Description</dt><dd><span>${$(ee)}</span>${m?`<div class="description-body">${$(m)}</div>`:``}</dd></div>
          </dl>
        </aside>
      </div>
      <button class="resize-handle" data-autotime-resize-widget type="button" title="Resize widget" aria-label="Resize widget"></button>
    </section>
    <section class="launcher" data-autotime-launcher aria-label="AutoTime widget minimized">
      <button class="launcher-logo" data-autotime-toggle-widget type="button" title="Open AutoTime widget. Triple click to close it." aria-label="Open AutoTime widget. Triple click to close it.">
        <img alt="" aria-hidden="true" src="${chrome.runtime.getURL(`icons/128.png`)}" />
      </button>
    </section>
  `}async function Lt(e){if(!e?.url)return _({area:`widget`,event:`track-job-missing-url`,message:`Track Job clicked without a visible job URL.`,status:`warning`}),`Open a visible job page, then try again.`;let t=await ie(),n=[E(e.url)];if(De(t,e.url)){_({area:`widget`,event:`track-job-duplicate-local`,message:`Job already exists in local extension storage.`,status:`info`,details:{url:e.url}});let r=await tt(t,n);return r.synced?`This job is already tracked and synced to dashboard - it'll be up to date there within a few seconds.`:`This job is already saved locally. ${r.reason}`}let r=Ze(e),i=[r,...t];await ae(r),_({area:`widget`,event:`track-job-saved-local`,message:`Job saved locally before dashboard sync.`,status:`success`,details:{company:e.company||`unknown`,roleTitle:e.roleTitle||`unknown`,url:e.url}});let a=await tt(i,n);return a.synced?`Job tracked and synced to dashboard - it'll appear there within a few seconds (the dashboard refreshes automatically while open).`:`Job saved locally. ${a.reason}`}function Rt(e=window.location.href){try{let t=new URL(e);return/\b(?:job|jobs|career|careers|position|positions|vacancy|vacancies|opening|openings|recruit|recruiting|apply)\b/i.test(`${t.hostname} ${t.pathname}`)}catch{return!1}}function zt(){let e=Q();return e.platform!==`Generic`||!!(e.roleTitle||e.company)||!!(e.jobDescription&&Rt(e.url))}function Bt(){try{zt()&&Ut()}catch{}}function Vt(){if(He)return;He=!0;let e=window.location.href,t=0,n=()=>{let n=window.location.href;n!==e&&(e=n,t=0),document.getElementById(k)||Bt(),t+=1,(t>=40||document.getElementById(k))&&(window.clearInterval(i),r.disconnect())},r=new MutationObserver(n);r.observe(document.documentElement,{childList:!0,subtree:!0});let i=window.setInterval(n,500);n()}function Ht(e,t){return(e?.authToken??``)===(t?.authToken??``)&&(e?.email??``)===(t?.email??``)&&(e?.plan??`free`)===(t?.plan??`free`)}function Ut(){if(document.getElementById(k)){I?.();return}let e=document.createElement(`div`);e.id=k,e.style.position=`fixed`,e.style.zIndex=`2147483647`;let t=Je(),n=z(t?.width??M,t?.height??N),r=B(t?.left??window.innerWidth-n.width-Re,t?.top??92,n.width,n.height);e.style.left=`${r.left}px`,e.style.top=`${r.top}px`,e.style.setProperty(`--autotime-widget-width`,`${n.width}px`),e.style.setProperty(`--autotime-widget-height`,`${n.height}px`);let i=e.attachShadow({mode:`open`});document.documentElement.append(e);let a=Q(),o=null,s=!1,c=t?.closed===!0,l=``;e.dataset.autotimeMinimized=String(s),e.dataset.autotimeClosed=String(c);let u=()=>{let t=e.getBoundingClientRect(),n=z(M,N);return z(s?P:t.width||n.width,s?F:t.height||n.height)};function d(){s=!s,c=!1,e.dataset.autotimeMinimized=String(s),e.dataset.autotimeClosed=String(c),V({closed:c});let t=e.getBoundingClientRect(),n=u(),r=B(t.left,t.top,s?P:n.width,s?F:n.height);e.style.left=`${r.left}px`,e.style.top=`${r.top}px`,H(r.left,r.top)}function f(){c=!1,s=!1,e.dataset.autotimeClosed=String(c),e.dataset.autotimeMinimized=String(s),V({closed:c});let t=e.getBoundingClientRect(),n=u(),r=B(t.left||window.innerWidth-n.width-Re,t.top||92,n.width,n.height);e.style.left=`${r.left}px`,e.style.top=`${r.top}px`,H(r.left,r.top)}I=f;function p(){e.dataset.autotimeMinimized=String(s),e.dataset.autotimeClosed=String(c),i.innerHTML=It({accountSession:o,details:a,status:l}),Wt(e,i,()=>a,e=>{l=e,p()})}i.addEventListener(j,e=>{e.stopPropagation(),d()}),window.setInterval(()=>{let e=Q(),t=!1;(e.url!==a.url||e.roleTitle!==a.roleTitle||e.company!==a.company||e.location!==a.location||e.jobDescription!==a.jobDescription)&&(a=e,t=!0),v().then(e=>{Ht(o,e)||(o=e,p())}),t&&p()},2500),i.addEventListener(Le,t=>{t.stopPropagation(),c=!0,s=!1,e.dataset.autotimeClosed=String(c),e.dataset.autotimeMinimized=String(s),V({closed:c})}),chrome.storage.onChanged.addListener((e,t)=>{t!==`local`||!e[`account-session`]||v().then(e=>{Ht(o,e)||(o=e,p())})}),chrome.runtime.onMessage.addListener((e,t,n)=>e?.type===`AUTOTIME_ACCOUNT_CONNECTED`?(v().then(e=>{o=e,_({area:`widget`,event:`account-connected-received`,message:`Widget received account connected broadcast.`,status:e?.authToken.trim()?`success`:`warning`}),p(),n({ok:!0})}),!0):!1),v().then(e=>{o=e,p()}),p(),window.addEventListener(`resize`,()=>{let t=e.getBoundingClientRect(),n=u(),r=B(t.left,t.top,s?P:n.width,s?F:n.height);e.style.left=`${r.left}px`,e.style.top=`${r.top}px`})}function Wt(e,t,n,r){let i=t.querySelector(`[data-autotime-drag-handle]`),a=t.querySelector(`[data-autotime-launcher]`),o=Array.from(t.querySelectorAll(`[data-autotime-collapse-widget]`)),s=t.querySelector(`[data-autotime-track-job]`),c=t.querySelector(`[data-autotime-open-dashboard]`),l=t.querySelector(`[data-autotime-resize-widget]`),u=e=>e.composedPath().find(e=>typeof e.matches==`function`&&e.matches(`button, [data-autotime-collapse-widget], [data-autotime-resize-widget], [data-autotime-track-job], [data-autotime-open-dashboard]`)),d=e=>{e.preventDefault(),e.stopPropagation(),t.dispatchEvent(new CustomEvent(j))};o.forEach(e=>{e.addEventListener(`pointerdown`,e=>{e.stopPropagation()}),e.addEventListener(`click`,e=>{d(e)})}),i&&(t=>{t.addEventListener(`pointerdown`,n=>{if(u(n))return;n.preventDefault(),t.setPointerCapture(n.pointerId);let r=e.getBoundingClientRect(),i=n.clientX,a=n.clientY,o=n.clientX-r.left,s=n.clientY-r.top,c=t=>{if(!(Math.abs(t.clientX-i)>3||Math.abs(t.clientY-a)>3))return;let n=B(t.clientX-o,t.clientY-s,r.width,r.height);e.style.left=`${n.left}px`,e.style.top=`${n.top}px`},l=n=>{t.releasePointerCapture(n.pointerId),t.removeEventListener(`pointermove`,c),t.removeEventListener(`pointerup`,l);let r=e.getBoundingClientRect();H(r.left,r.top)};t.addEventListener(`pointermove`,c),t.addEventListener(`pointerup`,l)})})(i),a&&(n=>{let r=null,i=!1,a=0,o=0,s=0,c=0,l=P,u=F,d=0,f=null,p=()=>{f!==null&&(window.clearTimeout(f),f=null)};n.addEventListener(`pointerdown`,t=>{t.stopPropagation(),r=t.pointerId,i=!1;let d=e.getBoundingClientRect();a=t.clientX,o=t.clientY,s=t.clientX-d.left,c=t.clientY-d.top,l=d.width,u=d.height;try{n.setPointerCapture(t.pointerId)}catch{}}),n.addEventListener(`pointermove`,t=>{if(r!==t.pointerId||!(Math.abs(t.clientX-a)>3||Math.abs(t.clientY-o)>3))return;i=!0;let n=B(t.clientX-s,t.clientY-c,l,u);e.style.left=`${n.left}px`,e.style.top=`${n.top}px`}),n.addEventListener(`pointerup`,t=>{if(r!==t.pointerId)return;try{n.releasePointerCapture(t.pointerId)}catch{}let i=e.getBoundingClientRect();H(i.left,i.top),r=null}),n.addEventListener(`pointercancel`,()=>{r=null}),n.addEventListener(`click`,e=>{if(e.preventDefault(),e.stopPropagation(),i){i=!1,d=0,p();return}if(d+=1,p(),d>=3){d=0,t.dispatchEvent(new CustomEvent(Le));return}f=window.setTimeout(()=>{d=0,t.dispatchEvent(new CustomEvent(j))},260)})})(a),l&&(n=>{n.addEventListener(`pointerdown`,r=>{r.preventDefault(),r.stopPropagation();let i=t.querySelector(`.widget`)?.getBoundingClientRect();if(!i)return;let a=r.clientX,o=r.clientY,s=i.width,c=i.height;try{n.setPointerCapture(r.pointerId)}catch{}let l=t=>{let n=z(s+t.clientX-a,c+t.clientY-o);e.style.setProperty(`--autotime-widget-width`,`${n.width}px`),e.style.setProperty(`--autotime-widget-height`,`${n.height}px`);let r=e.getBoundingClientRect(),i=B(r.left,r.top,n.width,n.height);e.style.left=`${i.left}px`,e.style.top=`${i.top}px`},u=t=>{try{n.releasePointerCapture(t.pointerId)}catch{}n.removeEventListener(`pointermove`,l),n.removeEventListener(`pointerup`,u);let r=e.getBoundingClientRect(),i=z(r.width,r.height);Xe(i.width,i.height),H(r.left,r.top)};n.addEventListener(`pointermove`,l),n.addEventListener(`pointerup`,u)})})(l),[s,c].forEach(e=>{e?.addEventListener(`pointerdown`,e=>{e.stopPropagation()})}),s?.addEventListener(`click`,e=>{e.preventDefault(),e.stopPropagation(),!s.disabled&&(s.disabled=!0,r(`Tracking job...`),Lt(n()).then(e=>r(e)).catch(()=>r(`Could not track this job.`)))}),c?.addEventListener(`click`,e=>{e.preventDefault(),e.stopPropagation();let t=c.dataset.autotimeDashboardUrl||`https://autotime-eu-apply.vercel.app/dashboard`,n=window.open(t,`_blank`);n?n.opener=null:window.location.href=t})}function Gt(){Vt(),chrome.runtime.onMessage.addListener((e,t,n)=>e?.type===`AUTOTIME_AUTOFILL_PROFILE`?(Mt().then(n),!0):e?.type===`AUTOTIME_INSERT_APPLICATION_CONTENT`?(Nt().then(n),!0):e?.type===`AUTOTIME_DETECT_JOB_PAGE`?(n(Q()),!1):e?.type===`AUTOTIME_SHOW_WIDGET`?(I?I():Ut(),n({ok:!0}),!1):!1)}var Kt=e({matches:[`*://*/*`],main(){Gt()}}),qt={debug:(...e)=>([...e],void 0),log:(...e)=>([...e],void 0),warn:(...e)=>([...e],void 0),error:(...e)=>([...e],void 0)},Jt=globalThis.browser?.runtime?.id?globalThis.browser:globalThis.chrome,Yt=class e extends Event{static EVENT_NAME=Xt(`wxt:locationchange`);constructor(t,n){super(e.EVENT_NAME,{}),this.newUrl=t,this.oldUrl=n}};function Xt(e){return`${Jt?.runtime?.id}:autotime:${e}`}var Zt=typeof globalThis.navigation?.addEventListener==`function`;function Qt(e){let t,n=!1;return{run(){n||(n=!0,t=new URL(location.href),Zt?globalThis.navigation.addEventListener(`navigate`,e=>{let n=new URL(e.destination.url);n.href!==t.href&&(window.dispatchEvent(new Yt(n,t)),t=n)},{signal:e.signal}):e.setInterval(()=>{let e=new URL(location.href);e.href!==t.href&&(window.dispatchEvent(new Yt(e,t)),t=e)},1e3))}}}var $t=class e{static SCRIPT_STARTED_MESSAGE_TYPE=Xt(`wxt:content-script-started`);id;abortController;locationWatcher=Qt(this);constructor(e,t){this.contentScriptName=e,this.options=t,this.id=Math.random().toString(36).slice(2),this.abortController=new AbortController,this.stopOldScripts(),this.listenForNewerScripts()}get signal(){return this.abortController.signal}abort(e){return this.abortController.abort(e)}get isInvalid(){return Jt.runtime?.id??this.notifyInvalidated(),this.signal.aborted}get isValid(){return!this.isInvalid}onInvalidated(e){return this.signal.addEventListener(`abort`,e),()=>this.signal.removeEventListener(`abort`,e)}block(){return new Promise(()=>{})}setInterval(e,t){let n=setInterval(()=>{this.isValid&&e()},t);return this.onInvalidated(()=>clearInterval(n)),n}setTimeout(e,t){let n=setTimeout(()=>{this.isValid&&e()},t);return this.onInvalidated(()=>clearTimeout(n)),n}requestAnimationFrame(e){let t=requestAnimationFrame((...t)=>{this.isValid&&e(...t)});return this.onInvalidated(()=>cancelAnimationFrame(t)),t}requestIdleCallback(e,t){let n=requestIdleCallback((...t)=>{this.signal.aborted||e(...t)},t);return this.onInvalidated(()=>cancelIdleCallback(n)),n}addEventListener(e,t,n,r){t===`wxt:locationchange`&&this.isValid&&this.locationWatcher.run(),e.addEventListener?.(t.startsWith(`wxt:`)?Xt(t):t,n,{...r,signal:this.signal})}notifyInvalidated(){this.abort(`Content script context invalidated`),qt.debug(`Content script "${this.contentScriptName}" context invalidated`)}stopOldScripts(){document.dispatchEvent(new CustomEvent(e.SCRIPT_STARTED_MESSAGE_TYPE,{detail:{contentScriptName:this.contentScriptName,messageId:this.id}})),window.postMessage({type:e.SCRIPT_STARTED_MESSAGE_TYPE,contentScriptName:this.contentScriptName,messageId:this.id},`*`)}verifyScriptStartedEvent(e){let t=e.detail?.contentScriptName===this.contentScriptName,n=e.detail?.messageId===this.id;return t&&!n}listenForNewerScripts(){let t=e=>{!(e instanceof CustomEvent)||!this.verifyScriptStartedEvent(e)||this.notifyInvalidated()};document.addEventListener(e.SCRIPT_STARTED_MESSAGE_TYPE,t),this.onInvalidated(()=>document.removeEventListener(e.SCRIPT_STARTED_MESSAGE_TYPE,t))}},en={debug:(...e)=>([...e],void 0),log:(...e)=>([...e],void 0),warn:(...e)=>([...e],void 0),error:(...e)=>([...e],void 0)};return(async()=>{try{let{main:e,...t}=Kt;return await e(new $t(`autotime`,t))}catch(e){throw en.error(`The content script "autotime" crashed on startup!`,e),e}})()})();
autotime;